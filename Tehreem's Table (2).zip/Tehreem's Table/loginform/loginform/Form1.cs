using NPOI.SS.Formula.Functions;

namespace loginform
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_exit_click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_user.Clear();
            txt_pass.Clear();
            txt_user.Focus();
        }
        private void btn_login_Click(object sender, EventArgs e)
        {
            string user, pass;
            user = "Tehreem_Akhtar";
            pass = "22011556-030";
            if ((txt_user.Text == user) && (txt_pass.Text == pass))

            { MessageBox.Show("Welcome user"); }
            else 
            {

                
                    double maxcount = 3;
                    double remain;
                
                    remain = maxcount - 1;
                    MessageBox.Show("wrong user or password" + "\t" + remain + "" + "tries left");
            }
            Application.Exit();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
