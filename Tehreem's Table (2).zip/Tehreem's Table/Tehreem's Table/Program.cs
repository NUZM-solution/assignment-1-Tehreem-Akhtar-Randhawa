namespace TehreemAkhtar_s_Table // Updated namespace
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new TehreemAkhtarForm()); // Updated to reference the correct form
        }
    }
}
